import { MyMediaPageComponent } from './my-media-page/my-media-page.component';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  
    {path : 'home', component : HomeComponent},
    {path : 'register',component :RegisterComponent},
    {path : 'app-my-media-page' ,component :MyMediaPageComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingcomponents= [HomeComponent,RegisterComponent,MyMediaPageComponent]; 


